#!/usr/bin/env python3
"""
txt2chunk.py

Split raw text files into approximate token‑sized chunks and write both raw
chunks and metadata chunk files.  Each raw chunk contains just the text
content for downstream processing, while each metadata chunk (.txt)
contains a header describing the source file, relative paths, chunk index,
and approximate token counts along with a link to the raw chunk file.

Directory layout::

    memory/
      text2chunk/
        raw/         ← raw text files (inputs)
        chunk_raw/   ← raw text chunks (outputs)
        chunk_txt/   ← metadata chunk txt files (outputs)

By default the script reads from ``memory/text2chunk/raw`` and writes
output into ``memory/text2chunk/chunk_raw`` and ``memory/text2chunk/chunk_txt``.

Usage examples::

    python txt2chunk.py
    python txt2chunk.py --raw-root memory/text2chunk/raw \
                       --chunk-raw memory/text2chunk/chunk_raw \
                       --chunk-txt memory/text2chunk/chunk_txt
    python txt2chunk.py --max-tokens 500 --overlap-tokens 50

The approximate token count is based on the heuristic that one token
corresponds to roughly four characters.  The script attempts to split
chunks at natural paragraph or sentence boundaries when possible to
improve coherence.
"""

import argparse
from pathlib import Path

# Recognised text file extensions.  Extend as necessary.
TEXT_EXTS = {
    ".txt", ".md", ".csv", ".json", ".jsonl",
    ".yaml", ".yml", ".xml", ".html", ".htm",
    ".log", ".ini", ".cfg", ".toml",
}

# Directories to ignore during recursion.
SKIP_DIRS = {".git", "__pycache__", ".venv", "venv", "node_modules"}


def file_uri(path: Path) -> str:
    """Return a file:// URI for a local path."""
    return path.resolve().as_uri()


def is_text_file(path: Path) -> bool:
    """Check if a file is a text file based on its suffix."""
    return path.suffix.lower() in TEXT_EXTS


def should_skip(path: Path) -> bool:
    """Return True if the path should be skipped based on directory names."""
    return any(part in SKIP_DIRS for part in path.parts)


def approx_token_len(text: str) -> int:
    """Approximate the token length of a string (1 token ≈ 4 characters)."""
    return max(1, len(text) // 4)


def split_by_approx_tokens(text: str, max_tokens: int, overlap_tokens: int) -> list[str]:
    """
    Split a string into chunks based on approximate token counts with overlap.

    Chunks are created based on character counts (max_tokens * 4).  The
    function tries to avoid splitting mid‑paragraph or mid‑sentence by
    backtracking to a recent newline or period if that cut occurs
    sufficiently far into the chunk (over half of the max length).  Overlap
    between consecutive chunks is specified in tokens and converted to
    characters.  The final list excludes empty or whitespace‑only chunks.
    """
    max_chars = max_tokens * 4
    overlap_chars = overlap_tokens * 4

    # Cap overlap to 1/5 of the max chars
    if overlap_chars >= max_chars:
        overlap_chars = max_chars // 5

    chunks: list[str] = []
    start = 0
    step = max_chars - overlap_chars

    while start < len(text):
        end = min(start + max_chars, len(text))
        chunk = text[start:end]

        # Avoid splitting mid‑sentence or mid‑paragraph
        if end < len(text):
            cut = max(chunk.rfind("\n\n"), chunk.rfind("\n"), chunk.rfind(". "))
            if cut > max_chars * 0.5:
                end = start + cut + 1
                chunk = text[start:end]

        chunks.append(chunk.strip())

        if end >= len(text):
            break

        start = max(0, end - overlap_chars)

    return [c for c in chunks if c.strip()]


def make_metadata_chunk_text(
    source_path: Path,
    raw_root: Path,
    chunk_text: str,
    chunk_index: int,
    chunk_total: int,
    max_tokens: int,
    raw_chunk_path: Path,
) -> str:
    """
    Construct the metadata text for a text chunk.  Includes source and
    relative paths, chunk index/total, approximate tokens and max tokens,
    and a link to the raw chunk file.
    """
    try:
        rel = source_path.relative_to(raw_root)
    except ValueError:
        rel = source_path.name

    return (
        "# TEXT CHUNK\n\n"
        f"Source file: [{source_path.name}]({file_uri(source_path)})\n"
        f"Source path: `{source_path.resolve()}`\n"
        f"Relative path: `{rel}`\n"
        f"Chunk: `{chunk_index} / {chunk_total}`\n"
        f"Approx tokens: `{approx_token_len(chunk_text)}`\n"
        f"Max tokens setting: `{max_tokens}`\n"
        f"Raw chunk file: {file_uri(raw_chunk_path)}\n\n"
        "---\n\n"
        f"{chunk_text}\n"
    )


def output_raw_chunk_path(
    source_path: Path,
    raw_root: Path,
    chunk_raw_root: Path,
    chunk_index: int,
) -> Path:
    """Determine the path of the raw chunk file (.txt)."""
    if raw_root.is_file():
        # If input is a single file, flatten the structure
        rel_path = Path(source_path.name)
    else:
        rel_path = source_path.relative_to(raw_root)
    rel_no_suffix = rel_path.with_suffix("")
    filename = f"{rel_no_suffix.name}__chunk_{chunk_index:04d}.txt"
    return chunk_raw_root / rel_no_suffix.parent / filename


def output_metadata_chunk_path(
    source_path: Path,
    raw_root: Path,
    chunk_txt_root: Path,
    chunk_index: int,
) -> Path:
    """Determine the path of the metadata chunk file (.txt)."""
    if raw_root.is_file():
        rel_path = Path(source_path.name)
    else:
        rel_path = source_path.relative_to(raw_root)
    rel_no_suffix = rel_path.with_suffix("")
    filename = f"{rel_no_suffix.name}__chunk_{chunk_index:04d}.txt"
    return chunk_txt_root / rel_no_suffix.parent / filename


def process_file(
    source_path: Path,
    raw_root: Path,
    chunk_raw_root: Path,
    chunk_txt_root: Path,
    max_tokens: int,
    overlap_tokens: int,
) -> int:
    """Split one text file into raw and metadata chunks."""
    text = source_path.read_text(encoding="utf-8", errors="ignore")
    if not text.strip():
        print(f"[SKIP] Empty: {source_path}")
        return 0

    chunks = split_by_approx_tokens(text, max_tokens, overlap_tokens)

    for i, chunk in enumerate(chunks, start=1):
        raw_path = output_raw_chunk_path(source_path, raw_root, chunk_raw_root, i)
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_text(chunk, encoding="utf-8")

        meta_path = output_metadata_chunk_path(source_path, raw_root, chunk_txt_root, i)
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        meta_text = make_metadata_chunk_text(
            source_path=source_path,
            raw_root=raw_root,
            chunk_text=chunk,
            chunk_index=i,
            chunk_total=len(chunks),
            max_tokens=max_tokens,
            raw_chunk_path=raw_path,
        )
        meta_path.write_text(meta_text, encoding="utf-8")

    print(f"[OK] {source_path} -> {len(chunks)} chunk(s)")
    return len(chunks)


def collect_files(input_path: Path) -> list[Path]:
    """Collect all text files under ``input_path`` (recursively)."""
    if input_path.is_file():
        return [input_path]
    files: list[Path] = []
    for p in input_path.rglob("*"):
        if should_skip(p):
            continue
        if p.is_file() and is_text_file(p):
            files.append(p)
    return files


def main() -> None:
    parser = argparse.ArgumentParser(description="Split text files into raw and metadata chunks.")
    parser.add_argument(
        "--raw-root",
        default="memory/text2chunk/raw",
        help="Input text file or folder (default: memory/text2chunk/raw)",
    )
    parser.add_argument(
        "--chunk-raw",
        default="memory/text2chunk/chunk_raw",
        help="Output folder for raw text chunks (default: memory/text2chunk/chunk_raw)",
    )
    parser.add_argument(
        "--chunk-txt",
        default="memory/text2chunk/chunk_txt",
        help="Output folder for metadata chunk txt files (default: memory/text2chunk/chunk_txt)",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=500,
        help="Approximate maximum tokens per chunk (default: 500)",
    )
    parser.add_argument(
        "--overlap-tokens",
        type=int,
        default=50,
        help="Approximate overlap tokens between chunks (default: 50)",
    )
    args = parser.parse_args()

    raw_root = Path(args.raw_root)
    chunk_raw_root = Path(args.chunk_raw)
    chunk_txt_root = Path(args.chunk_txt)

    if not raw_root.exists():
        raise SystemExit(f"[ERROR] Input not found: {raw_root}")

    files = collect_files(raw_root)
    if not files:
        print("[INFO] No text files found.")
        return

    total_chunks = 0
    for source_path in files:
        total_chunks += process_file(
            source_path=source_path,
            raw_root=raw_root,
            chunk_raw_root=chunk_raw_root,
            chunk_txt_root=chunk_txt_root,
            max_tokens=args.max_tokens,
            overlap_tokens=args.overlap_tokens,
        )

    print(f"[DONE] Files: {len(files)}")
    print(f"[DONE] Chunks: {total_chunks}")
    print(f"[DONE] Raw chunk folder: {chunk_raw_root}")
    print(f"[DONE] Metadata chunk folder: {chunk_txt_root}")


if __name__ == "__main__":
    main()