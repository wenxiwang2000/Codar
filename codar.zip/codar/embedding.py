#!/usr/bin/env python3
"""
embedding.py

Generate simple numeric embeddings for summary text entries.

Supports both formats:

Old:
  - CHUNK: file:///...
    summary text

New:
  - CHUNK TXT: file:///...
    RAW CHUNK: file:///...
    RAW FILE: file:///...
    SUMMARY:

    extracted important text...

Use:
  python embedding.py --memory memory

Output:
  memory/embeddings/embedding_cache.json
  memory/embeddings/embedding_vectors.json
  memory/embeddings/embedding_entries.json
"""

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Tuple, Any

from sklearn.feature_extraction.text import HashingVectorizer


Entry = Tuple[str, str]


def parse_summary_file(summary_path: Path) -> List[Entry]:
    """
    Return list of:
      (chunk_key, summary_text)

    chunk_key is usually the CHUNK TXT / CHUNK URI.
    summary_text is the text after SUMMARY: until the next chunk or section.
    """
    entries: List[Entry] = []

    if not summary_path.exists():
        return entries

    lines = summary_path.read_text(encoding="utf-8", errors="ignore").splitlines()

    i = 0
    while i < len(lines):
        stripped = lines[i].strip()

        # New format
        if stripped.startswith("- CHUNK TXT:"):
            chunk_key = stripped.split(":", 1)[1].strip()
            summary_lines: List[str] = []

            i += 1

            # Move until SUMMARY:
            while i < len(lines):
                s = lines[i].strip()
                if s.startswith("SUMMARY:"):
                    after = s[len("SUMMARY:"):].strip()
                    if after:
                        summary_lines.append(after)
                    i += 1
                    break
                if s.startswith("- CHUNK TXT:") or s.startswith("- CHUNK:") or s.startswith("## "):
                    break
                i += 1

            # Collect summary content until next chunk/section
            while i < len(lines):
                s = lines[i].strip()
                if s.startswith("- CHUNK TXT:") or s.startswith("- CHUNK:") or s.startswith("## "):
                    break

                if s and not s.startswith("RAW CHUNK:") and not s.startswith("RAW FILE:"):
                    summary_lines.append(s)

                i += 1

            summary_text = " ".join(summary_lines).strip()
            if summary_text:
                entries.append((chunk_key, summary_text))
            continue

        # Old format
        if stripped.startswith("- CHUNK:"):
            chunk_key = stripped.split(":", 1)[1].strip()
            summary_lines: List[str] = []

            i += 1
            while i < len(lines):
                s = lines[i].strip()
                if s.startswith("- CHUNK TXT:") or s.startswith("- CHUNK:") or s.startswith("## "):
                    break
                if s:
                    summary_lines.append(s)
                i += 1

            summary_text = " ".join(summary_lines).strip()
            if summary_text:
                entries.append((chunk_key, summary_text))
            continue

        i += 1

    return entries


def load_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def compute_embeddings(
    entries: List[Entry],
    cache: Dict[str, int],
    vectors: Dict[str, List[float]],
    dim: int,
) -> None:
    vectorizer = HashingVectorizer(
        n_features=dim,
        alternate_sign=False,
        norm="l2",
    )

    for key, text in entries:
        text = re.sub(r"\s+", " ", text).strip()
        length = len(text)

        if cache.get(key) == length and key in vectors:
            continue

        X = vectorizer.transform([text])
        vectors[key] = X.toarray()[0].astype(float).tolist()
        cache[key] = length


def make_entries_json(entries: List[Entry]) -> List[Dict[str, str]]:
    return [
        {
            "chunk_key": key,
            "summary_text": text,
        }
        for key, text in entries
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate embeddings for summary entries.")
    parser.add_argument("--memory", default="memory", help="Root memory folder")
    parser.add_argument("--dim", type=int, default=256, help="Embedding dimension")
    args = parser.parse_args()

    memory = Path(args.memory)
    summary_path = memory / "chunk2contents" / "summary" / "summary.txt"

    if not summary_path.exists():
        raise SystemExit(f"[ERROR] Summary file not found: {summary_path}")

    embed_dir = memory / "embeddings"
    cache_path = embed_dir / "embedding_cache.json"
    vec_path = embed_dir / "embedding_vectors.json"
    entries_path = embed_dir / "embedding_entries.json"

    entries = parse_summary_file(summary_path)

    if not entries:
        print("[INFO] No summary entries found to embed.")
        print(f"[INFO] Checked: {summary_path}")
        return

    cache: Dict[str, int] = load_json(cache_path)
    vectors: Dict[str, List[float]] = load_json(vec_path)

    compute_embeddings(entries, cache, vectors, args.dim)

    current_keys = {k for k, _ in entries}
    for stale in list(vectors.keys()):
        if stale not in current_keys:
            vectors.pop(stale, None)
            cache.pop(stale, None)

    save_json(cache_path, cache)
    save_json(vec_path, vectors)
    save_json(entries_path, make_entries_json(entries))

    print(f"[DONE] Updated embeddings: {len(entries)} entries, dimension {args.dim}")
    print(f"[DONE] Entries: {entries_path}")
    print(f"[DONE] Cache: {cache_path}")
    print(f"[DONE] Vectors: {vec_path}")


if __name__ == "__main__":
    main()
