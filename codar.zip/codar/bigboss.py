#!/usr/bin/env python3
r"""
bigboss.py

One-command controller for your local memory system.

No llama summary. Final summary uses base.py embedding extraction.

Use:
  python bigboss.py --folder "C:\path\to\input_folder" --chunk-size 500 --embed
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

CODE_EXTS = {
    ".py", ".js", ".ts", ".tsx", ".jsx",
    ".html", ".css", ".scss",
    ".json", ".yaml", ".yml",
    ".java", ".c", ".cpp", ".h", ".hpp",
    ".cs", ".go", ".rs", ".php", ".rb",
    ".r", ".sql", ".sh", ".bat", ".ps1",
    ".xml", ".toml", ".ini", ".cfg",
}

TEXT_EXTS = {
    ".txt", ".md", ".csv", ".jsonl", ".log",
    ".yaml", ".yml", ".xml", ".html", ".htm",
}

PIC_EXTS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp",
}

SKIP_DIRS = {
    ".git", "__pycache__", ".venv", "venv", "env",
    "node_modules", "dist", "build", ".idea", ".vscode",
    "memory", "llama", "tesseract",
}


def run_cmd(cmd: list[str]) -> None:
    print("\n[RUN]", " ".join(f'"{x}"' if " " in x else x for x in cmd))
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        raise SystemExit(f"[ERROR] Command failed: {' '.join(cmd)}")


def clean_folder(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def should_skip(path: Path) -> bool:
    return any(part in SKIP_DIRS for part in path.parts)


def safe_copy(src: Path, input_root: Path, dst_root: Path) -> Path:
    rel = src.relative_to(input_root)
    dst = dst_root / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return dst


def collect_files(input_root: Path) -> list[Path]:
    files = []
    for p in input_root.rglob("*"):
        if should_skip(p):
            continue
        if p.is_file():
            files.append(p)
    return files


def route_files(input_root: Path, memory: Path) -> dict[str, int]:
    code_raw = memory / "code2text" / "raw"
    text_raw = memory / "text2chunk" / "raw"
    pic_raw = memory / "pic2text" / "raw"
    other_raw = memory / "other" / "raw"

    clean_folder(code_raw)
    clean_folder(text_raw)
    clean_folder(pic_raw)
    clean_folder(other_raw)

    counts = {"code": 0, "text": 0, "pic": 0, "other": 0}

    for src in collect_files(input_root):
        suffix = src.suffix.lower()
        name = src.name.lower()

        if name in {"dockerfile", "makefile"} or suffix in CODE_EXTS:
            safe_copy(src, input_root, code_raw)
            counts["code"] += 1
        elif suffix in TEXT_EXTS:
            safe_copy(src, input_root, text_raw)
            counts["text"] += 1
        elif suffix in PIC_EXTS:
            safe_copy(src, input_root, pic_raw)
            counts["pic"] += 1
        else:
            safe_copy(src, input_root, other_raw)
            counts["other"] += 1

    return counts


def copy_txt_files(src_root: Path, dst_root: Path, prefix: str) -> int:
    if not src_root.exists():
        return 0

    count = 0
    for src in src_root.rglob("*.txt"):
        rel = src.relative_to(src_root)
        dst = dst_root / prefix / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        count += 1
    return count


def main() -> None:
    parser = argparse.ArgumentParser(description="One-command memory builder without llama.")
    parser.add_argument("--folder", required=True)
    parser.add_argument("--chunk-size", type=int, default=500)
    parser.add_argument("--overlap", type=int, default=50)
    parser.add_argument("--code-lines", type=int, default=None)
    parser.add_argument("--ratio", type=float, default=0.1, help="Keep 10 percent important text from each chunk")
    parser.add_argument("--embed", action="store_true", help="Also run embedding.py vector index after summary")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    input_root = Path(args.folder).resolve()

    if not input_root.exists():
        raise SystemExit(f"[ERROR] Input folder not found: {input_root}")

    memory = base / "memory"

    code_raw = memory / "code2text" / "raw"
    code_chunk_raw = memory / "code2text" / "chunk_raw"
    code_chunks = memory / "code2text" / "chunk_txt"

    text_raw = memory / "text2chunk" / "raw"
    text_chunk_raw = memory / "text2chunk" / "chunk_raw"
    text_chunks = memory / "text2chunk" / "chunk_txt"

    pic_raw = memory / "pic2text" / "raw"
    pic_txt = memory / "pic2text" / "txt_output"
    pic_chunk_raw = memory / "pic2text" / "chunk_raw"
    pic_chunks = memory / "pic2text" / "chunk_txt"

    all_chunks = memory / "chunk2contents" / "input_chunks"
    summary_dir = memory / "chunk2contents" / "summary"
    summary_out = summary_dir / "summary.txt"

    clean_folder(code_chunk_raw)
    clean_folder(code_chunks)
    clean_folder(text_chunk_raw)
    clean_folder(text_chunks)
    clean_folder(pic_txt)
    clean_folder(pic_chunk_raw)
    clean_folder(pic_chunks)
    clean_folder(all_chunks)
    summary_dir.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Input folder: {input_root}")
    print(f"[INFO] Chunk size: {args.chunk_size} tokens")
    print("[INFO] Final summary: embedding extraction, no llama")

    counts = route_files(input_root, memory)

    print("[INFO] Routed files:")
    print(f"  code: {counts['code']}")
    print(f"  text: {counts['text']}")
    print(f"  pdf/image: {counts['pic']}")
    print(f"  other: {counts['other']}")

    py = sys.executable

    if counts["pic"] > 0:
        run_cmd([
            py, str(base / "pic2textV2.py"),
            "--raw-root", str(pic_raw),
            "--txt-out", str(pic_txt),
            "--tesseract-dir", str(base / "tesseract"),
        ])

        run_cmd([
            py, str(base / "txt2chunk.py"),
            "--raw-root", str(pic_txt),
            "--chunk-raw", str(pic_chunk_raw),
            "--chunk-txt", str(pic_chunks),
            "--max-tokens", str(args.chunk_size),
            "--overlap-tokens", str(args.overlap),
        ])

    if counts["text"] > 0:
        run_cmd([
            py, str(base / "txt2chunk.py"),
            "--raw-root", str(text_raw),
            "--chunk-raw", str(text_chunk_raw),
            "--chunk-txt", str(text_chunks),
            "--max-tokens", str(args.chunk_size),
            "--overlap-tokens", str(args.overlap),
        ])

    if counts["code"] > 0:
        code_lines = args.code_lines if args.code_lines is not None else max(40, args.chunk_size // 4)

        run_cmd([
            py, str(base / "code2chunk.py"),
            "--raw-root", str(code_raw),
            "--chunk-raw", str(code_chunk_raw),
            "--chunk-txt", str(code_chunks),
            "--max-lines", str(code_lines),
            "--overlap", str(max(5, code_lines // 8)),
        ])

    copied = 0
    copied += copy_txt_files(code_chunks, all_chunks, "code")
    copied += copy_txt_files(text_chunks, all_chunks, "text")
    copied += copy_txt_files(pic_chunks, all_chunks, "pic")

    print(f"[INFO] Copied {copied} chunk file(s) into: {all_chunks}")

    run_cmd([
        py, str(base / "chunks2contents.py"),
        "--input", str(all_chunks),
        "--out", str(summary_out),
        "--ratio", str(args.ratio),
    ])

    print("\n[DONE] Bigboss complete.")
    print(f"[DONE] Summary: {summary_out}")

    if args.embed:
        run_cmd([
            py, str(base / "embedding.py"),
            "--memory", str(memory),
        ])


if __name__ == "__main__":
    main()
