#!/usr/bin/env python3
"""
pic2textV2.py

Extract text from PDF and image files stored in a memory folder and write
corresponding text files with rich headers linking back to the source.  If
selectable text is present in a PDF, it is extracted using PyMuPDF.  If
little or no text is found (e.g. a scanned document), or for images, the
script falls back to OCR via Tesseract.  Each output file begins with a
header containing links to the original file and page information.

Directory layout::

    memory/
      pic2text/
        raw/        ← raw PDF/image files (inputs)
        txt_output/ ← extracted text files (outputs)

By default the script reads from ``memory/pic2text/raw`` and writes
outputs into ``memory/pic2text/txt_output``.  Tesseract is searched for
in a sibling ``tesseract`` directory or in common install locations.

Usage examples::

    python pic2textV2.py
    python pic2textV2.py --raw-root memory/pic2text/raw \
                         --txt-out memory/pic2text/txt_output \
                         --tesseract-dir tesseract

Dependencies:
    pip install pymupdf pillow

The script is platform‑independent; it looks for ``tesseract.exe`` on
Windows but will also work with ``tesseract`` on Unix.
"""

import argparse
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import quote

SUPPORTED_IMAGES = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}
SUPPORTED_PDFS = {".pdf"}


def file_uri(path: Path) -> str:
    """Create a clickable file:// URI for a local path."""
    return path.resolve().as_uri()


def markdown_link(label: str, path: Path) -> str:
    """Return a Markdown link with file:// URI."""
    return f"[{label}]({file_uri(path)})"


def find_tesseract_exe(base_dir: Path) -> Path | None:
    """
    Search for ``tesseract.exe`` or ``tesseract`` in the given base
    directory recursively.  If not found, check a common Windows install
    location.  Returns ``None`` if not found.
    """
    for name in ["tesseract.exe", "tesseract"]:
        for p in base_dir.rglob(name):
            if p.is_file():
                return p
    common = Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe")
    if common.exists():
        return common
    return None


def run_tesseract_image(image_path: Path, tesseract_exe: Path, lang: str = "eng") -> str:
    cmd = [str(tesseract_exe), str(image_path), "stdout", "-l", lang]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
    if result.returncode != 0:
        return "[OCR ERROR]\n" + result.stderr.strip()
    return result.stdout.strip()


def extract_pdf_text_pymupdf(pdf_path: Path) -> list[str]:
    """Extract selectable text from each page of a PDF using PyMuPDF."""
    try:
        import fitz  # type: ignore
    except ImportError:
        return ["[ERROR] PyMuPDF missing. Install with: pip install pymupdf"]
    page_texts: list[str] = []
    try:
        doc = fitz.open(pdf_path)
        for page in doc:
            page_texts.append(page.get_text("text").strip())
        doc.close()
    except Exception as e:
        return [f"[PDF TEXT ERROR] {e}"]
    return page_texts


def ocr_pdf_pages_with_pymupdf(pdf_path: Path, tesseract_exe: Path, lang: str = "eng", zoom: float = 2.0) -> list[str]:
    """
    Render each page of a PDF to a temporary PNG image and run OCR on it.
    Uses PyMuPDF for rendering.  Returns a list of page texts.
    """
    try:
        import fitz  # type: ignore
    except ImportError:
        return ["[ERROR] PyMuPDF missing. Install with: pip install pymupdf"]
    page_texts: list[str] = []
    try:
        doc = fitz.open(pdf_path)
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            for page_index, page in enumerate(doc, start=1):
                mat = fitz.Matrix(zoom, zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                img_path = tmp_dir / f"page_{page_index}.png"
                pix.save(img_path)
                text = run_tesseract_image(img_path, tesseract_exe, lang)
                page_texts.append(text)
        doc.close()
    except Exception as e:
        return [f"[PDF OCR ERROR] {e}"]
    return page_texts


def extract_pdf_auto(pdf_path: Path, tesseract_exe: Path | None, lang: str, min_chars: int) -> tuple[list[str], str]:
    """Try selectable text extraction first, then fallback to OCR if needed."""
    page_texts = extract_pdf_text_pymupdf(pdf_path)
    total_chars = sum(len(x.strip()) for x in page_texts)
    if total_chars >= min_chars:
        return page_texts, "PyMuPDF selectable PDF text"
    if tesseract_exe is None:
        page_texts.append("[OCR SKIPPED] No tesseract.exe found. Put it in ./tesseract/ or install Tesseract.")
        return page_texts, "PyMuPDF only, OCR skipped"
    print(f"[INFO] PDF text is too small, using OCR fallback: {pdf_path}")
    return ocr_pdf_pages_with_pymupdf(pdf_path, tesseract_exe, lang), "Tesseract OCR PDF pages"


def extract_image_text(image_path: Path, tesseract_exe: Path | None, lang: str) -> tuple[list[str], str]:
    """Extract text from a single image using Tesseract."""
    if tesseract_exe is None:
        return (["[OCR ERROR] No tesseract.exe found. Put it in ./tesseract/ or install Tesseract."], "OCR failed, no Tesseract")
    text = run_tesseract_image(image_path, tesseract_exe, lang)
    return ([text], "Tesseract OCR image")


def make_txt_header(raw_path: Path, raw_root: Path, txt_path: Path, method: str, page_count: int) -> str:
    """Create a header for the extracted text file with links back to the source."""
    try:
        relative_raw = raw_path.relative_to(raw_root)
    except ValueError:
        relative_raw = raw_path.name
    lines: list[str] = []
    lines.append("# MEMORY TEXT VERSION")
    lines.append("")
    lines.append(f"Source file: {markdown_link(raw_path.name, raw_path)}")
    lines.append(f"Source path: `{raw_path.resolve()}`")
    lines.append(f"Relative memory path: `{relative_raw}`")
    lines.append(f"TXT output path: `{txt_path.resolve()}`")
    lines.append(f"Extraction method: `{method}`")
    lines.append(f"Page count: `{page_count}`")
    lines.append("")
    lines.append("## Page links")
    lines.append("")
    for i in range(1, page_count + 1):
        if raw_path.suffix.lower() == ".pdf":
            label = f"Page {i} in source PDF"
        else:
            label = "Page 1 source image"
        lines.append(f"- {markdown_link(label, raw_path)}")
    lines.append("")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


def format_pages(raw_path: Path, raw_root: Path, txt_path: Path, page_texts: list[str], method: str) -> str:
    """Combine the header and per‑page sections into the final text file content."""
    header = make_txt_header(raw_path, raw_root, txt_path, method, len(page_texts))
    lines: list[str] = [header]
    for i, text in enumerate(page_texts, start=1):
        lines.append(f"===== PAGE {i} START =====")
        lines.append(f"RAW LINK: {file_uri(raw_path)}")
        lines.append("")
        lines.append(text.strip() if text.strip() else "[empty page]")
        lines.append("")
        lines.append(f"===== PAGE {i} END =====")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def safe_txt_output_path(raw_path: Path, raw_root: Path, txt_root: Path) -> Path:
    """Preserve subfolder structure: raw_root/foo/bar.pdf -> txt_root/foo/bar.txt"""
    rel = raw_path.relative_to(raw_root)
    return (txt_root / rel).with_suffix(".txt")


def collect_memory_files(raw_root: Path) -> list[Path]:
    """Return a list of PDF and image files under ``raw_root``."""
    files: list[Path] = []
    allowed = SUPPORTED_PDFS.union(SUPPORTED_IMAGES)
    for p in raw_root.rglob("*"):
        if p.is_file() and p.suffix.lower() in allowed:
            files.append(p)
    return files


def process_one_file(raw_path: Path, raw_root: Path, txt_root: Path, tesseract_exe: Path | None, lang: str, min_chars: int) -> None:
    suffix = raw_path.suffix.lower()
    if suffix in SUPPORTED_PDFS:
        print(f"[INFO] PDF: {raw_path}")
        page_texts, method = extract_pdf_auto(raw_path, tesseract_exe, lang, min_chars)
    elif suffix in SUPPORTED_IMAGES:
        print(f"[INFO] IMAGE: {raw_path}")
        page_texts, method = extract_image_text(raw_path, tesseract_exe, lang)
    else:
        print(f"[SKIP] Unsupported file type: {raw_path}")
        return
    txt_path = safe_txt_output_path(raw_path, raw_root, txt_root)
    txt_path.parent.mkdir(parents=True, exist_ok=True)
    content = format_pages(raw_path, raw_root, txt_path, page_texts, method)
    txt_path.write_text(content, encoding="utf-8")
    print(f"[OK] Wrote TXT: {txt_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert memory PDF/images into linked TXT files.")
    parser.add_argument(
        "--raw-root",
        default="memory/pic2text/raw",
        help="Raw PDF/image folder (default: memory/pic2text/raw)",
    )
    parser.add_argument(
        "--txt-out",
        default="memory/pic2text/txt_output",
        help="TXT output folder (default: memory/pic2text/txt_output)",
    )
    parser.add_argument(
        "--tesseract-dir",
        default="tesseract",
        help="Folder containing tesseract.exe (default: tesseract)",
    )
    parser.add_argument(
        "--tesseract-exe",
        default=None,
        help="Direct path to tesseract executable (optional)",
    )
    parser.add_argument(
        "--lang",
        default="eng",
        help="Tesseract OCR language code (default: eng)",
    )
    parser.add_argument(
        "--min-chars",
        type=int,
        default=30,
        help="If extracted PDF text has fewer characters, fallback to OCR (default: 30)",
    )
    args = parser.parse_args()
    base_dir = Path(__file__).resolve().parent
    raw_root = Path(args.raw_root)
    txt_root = Path(args.txt_out)
    if not raw_root.exists():
        raise SystemExit(f"[ERROR] Raw memory folder not found: {raw_root}")
    # Locate tesseract
    if args.tesseract_exe:
        tesseract_exe = Path(args.tesseract_exe)
    else:
        # Search in provided tesseract directory first, then base directory
        tesseract_exe = find_tesseract_exe(base_dir / args.tesseract_dir)
        if tesseract_exe is None:
            tesseract_exe = find_tesseract_exe(base_dir)
    if tesseract_exe and tesseract_exe.exists():
        print(f"[INFO] Using Tesseract: {tesseract_exe}")
    else:
        tesseract_exe = None
        print("[WARN] No tesseract executable found. Only selectable PDF text will be used; image OCR will be skipped.")
    files = collect_memory_files(raw_root)
    if not files:
        print("[INFO] No PDF/image files found in memory folder.")
        return
    for raw_path in files:
        process_one_file(raw_path, raw_root, txt_root, tesseract_exe, args.lang, args.min_chars)
    print(f"[DONE] Converted {len(files)} file(s).")
    print(f"[DONE] TXT output folder: {txt_root}")


if __name__ == "__main__":
    main()