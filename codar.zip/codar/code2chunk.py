#!/usr/bin/env python3
"""
code2chunk.py

Convert raw code files into both raw and metadata chunk files for local LLM
memory and retrieval.  This script walks a directory of source code files,
splits each file into line‑based chunks with optional overlap, and writes
two outputs per chunk:

* A raw chunk file in the same language as the source (no header), saved
  under ``chunk_raw``.  These files preserve the original code exactly
  and use the original file extension so editors can open them easily.
* A metadata chunk file in ``chunk_txt`` with a Markdown header.  The
  header captures the source file, full and relative paths, chunk index
  and line range, plus a link to the corresponding raw chunk file.

The default directory layout assumes a project structured like this::

    memory/
      code2text/
        raw/         ← raw code files (inputs)
        chunk_raw/   ← raw code chunks (outputs)
        chunk_txt/   ← metadata chunk txt files (outputs)

You can override these locations with command‑line options.

Usage examples::

    python code2chunk.py
    python code2chunk.py --raw-root memory/code2text/raw \
                        --chunk-raw memory/code2text/chunk_raw \
                        --chunk-txt memory/code2text/chunk_txt
    python code2chunk.py --max-lines 200 --overlap 20

This script is cross‑platform and works under Windows and Unix.  It
ignores hidden folders such as ``.git`` and ``__pycache__``.
"""

import argparse
from pathlib import Path

# Recognised code file extensions.  Feel free to extend this set.
CODE_EXTS = {
    ".py", ".js", ".ts", ".tsx", ".jsx",
    ".html", ".css", ".scss",
    ".json", ".yaml", ".yml",
    ".md", ".txt",
    ".java", ".c", ".cpp", ".h", ".hpp",
    ".cs", ".go", ".rs", ".php", ".rb",
    ".r", ".sql", ".sh", ".bat", ".ps1",
    ".xml", ".toml", ".ini", ".cfg",
    ".dockerfile",
}

# Folders to skip when scanning for code files.
SKIP_DIRS = {
    ".git", "__pycache__", ".venv", "venv", "env",
    "node_modules", "dist", "build", ".idea", ".vscode",
}


def file_uri(path: Path) -> str:
    """Return a file:// URI for a local path."""
    return path.resolve().as_uri()


def is_code_file(path: Path) -> bool:
    """Check whether ``path`` looks like a code file based on its suffix or name."""
    name = path.name.lower()
    suffix = path.suffix.lower()
    # Treat Dockerfile / Makefile as code even without suffix.
    if name in {"dockerfile", "makefile"}:
        return True
    return suffix in CODE_EXTS


def should_skip(path: Path) -> bool:
    """Return True if any part of ``path`` is in the skip list."""
    return any(part in SKIP_DIRS for part in path.parts)


def read_text_safe(path: Path) -> str:
    """Read text from ``path`` as UTF‑8, ignoring errors."""
    return path.read_text(encoding="utf-8", errors="ignore")


def split_lines_with_overlap(
    lines: list[str],
    max_lines: int,
    overlap: int,
) -> list[tuple[int, int, list[str]]]:
    """
    Split a list of lines into chunks with overlap.

    Returns a list of tuples ``(start_line, end_line, chunk_lines)``.  Line
    numbers are 1‑based and inclusive.  Overlap is applied between
    consecutive chunks; if overlap >= max_lines, it is reduced to one
    fifth of max_lines to avoid zero or negative step.
    """
    if max_lines <= 0:
        raise ValueError("max_lines must be > 0")

    # Limit overlap to at most 1/5 of the chunk size
    if overlap >= max_lines:
        overlap = max_lines // 5

    chunks: list[tuple[int, int, list[str]]] = []
    step = max_lines - overlap
    start = 0

    while start < len(lines):
        end = min(start + max_lines, len(lines))
        chunk = lines[start:end]
        chunks.append((start + 1, end, chunk))
        if end >= len(lines):
            break
        start += step

    return chunks


def make_chunk_text(
    source_path: Path,
    raw_root: Path,
    chunk_index: int,
    chunk_total: int,
    start_line: int,
    end_line: int,
    chunk_lines: list[str],
    raw_chunk_path: Path,
) -> str:
    """
    Build the metadata text for a code chunk.

    ``raw_root`` is used to compute the relative path of the source file.
    ``raw_chunk_path`` points to the raw chunk file corresponding to this
    chunk.  The returned string contains a Markdown header followed by
    fenced code containing the chunk's lines.
    """
    try:
        rel = source_path.relative_to(raw_root)
    except ValueError:
        rel = source_path.name

    language = source_path.suffix.lstrip(".") or "text"

    header = [
        "# CODE CHUNK",
        "",
        f"Source file: [{source_path.name}]({file_uri(source_path)})",
        f"Source path: `{source_path.resolve()}`",
        f"Relative path: `{rel}`",
        f"Chunk: `{chunk_index} / {chunk_total}`",
        f"Lines: `{start_line}-{end_line}`",
        f"Raw chunk file: {file_uri(raw_chunk_path)}",
        "",
        "---",
        "",
        f"```{language}",
    ]

    body = "".join(chunk_lines)
    footer = ["```", ""]

    return "\n".join(header) + body + "\n".join(footer)


def output_raw_chunk_path(
    source_path: Path,
    raw_root: Path,
    chunk_raw_root: Path,
    chunk_index: int,
) -> Path:
    """
    Compute the output path for a raw chunk file.  The path preserves the
    subfolder structure beneath ``raw_root`` and uses the original file
    extension.
    """
    rel = source_path.relative_to(raw_root)
    rel_no_suffix = rel.with_suffix("")
    suffix = source_path.suffix or ""
    filename = f"{rel_no_suffix.name}__chunk_{chunk_index:04d}{suffix}"
    return chunk_raw_root / rel_no_suffix.parent / filename


def output_metadata_path(
    source_path: Path,
    raw_root: Path,
    chunk_txt_root: Path,
    chunk_index: int,
) -> Path:
    """
    Compute the output path for a metadata chunk file (.txt).  Uses the
    same naming scheme as the raw chunk but always with a .txt suffix.
    """
    rel = source_path.relative_to(raw_root)
    rel_no_suffix = rel.with_suffix("")
    filename = f"{rel_no_suffix.name}__chunk_{chunk_index:04d}.txt"
    return chunk_txt_root / rel_no_suffix.parent / filename


def process_file(
    source_path: Path,
    raw_root: Path,
    chunk_raw_root: Path,
    chunk_txt_root: Path,
    max_lines: int,
    overlap: int,
) -> int:
    """
    Process a single source code file: split into chunks, write raw and
    metadata files.  Returns the number of chunks produced.
    """
    text = read_text_safe(source_path)
    if not text.strip():
        print(f"[SKIP] Empty file: {source_path}")
        return 0

    lines = text.splitlines(keepends=True)
    chunks = split_lines_with_overlap(lines, max_lines=max_lines, overlap=overlap)

    for i, (start_line, end_line, chunk_lines) in enumerate(chunks, start=1):
        # raw chunk path
        raw_chunk_path = output_raw_chunk_path(source_path, raw_root, chunk_raw_root, i)
        raw_chunk_path.parent.mkdir(parents=True, exist_ok=True)
        raw_chunk_path.write_text("".join(chunk_lines), encoding="utf-8")

        # metadata chunk path
        meta_path = output_metadata_path(source_path, raw_root, chunk_txt_root, i)
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        meta_text = make_chunk_text(
            source_path=source_path,
            raw_root=raw_root,
            chunk_index=i,
            chunk_total=len(chunks),
            start_line=start_line,
            end_line=end_line,
            chunk_lines=chunk_lines,
            raw_chunk_path=raw_chunk_path,
        )
        meta_path.write_text(meta_text, encoding="utf-8")

    print(f"[OK] {source_path} -> {len(chunks)} chunk(s)")
    return len(chunks)


def collect_code_files(raw_root: Path) -> list[Path]:
    """Recursively collect all code files under ``raw_root``."""
    files: list[Path] = []
    for p in raw_root.rglob("*"):
        if should_skip(p):
            continue
        if p.is_file() and is_code_file(p):
            files.append(p)
    return files


def main() -> None:
    parser = argparse.ArgumentParser(description="Split code files into raw and metadata chunks.")
    parser.add_argument(
        "--raw-root",
        default="memory/code2text/raw",
        help="Folder containing raw code files (default: memory/code2text/raw)",
    )
    parser.add_argument(
        "--chunk-raw",
        default="memory/code2text/chunk_raw",
        help="Output folder for raw code chunks (default: memory/code2text/chunk_raw)",
    )
    parser.add_argument(
        "--chunk-txt",
        default="memory/code2text/chunk_txt",
        help="Output folder for metadata chunk txt files (default: memory/code2text/chunk_txt)",
    )
    parser.add_argument(
        "--max-lines",
        type=int,
        default=160,
        help="Maximum number of lines per chunk (default: 160)",
    )
    parser.add_argument(
        "--overlap",
        type=int,
        default=20,
        help="Number of overlapping lines between chunks (default: 20)",
    )
    args = parser.parse_args()

    raw_root = Path(args.raw_root)
    chunk_raw_root = Path(args.chunk_raw)
    chunk_txt_root = Path(args.chunk_txt)

    if not raw_root.exists():
        raise SystemExit(f"[ERROR] Raw code folder not found: {raw_root}")

    files = collect_code_files(raw_root)
    if not files:
        print("[INFO] No code files found.")
        return

    total_chunks = 0
    for source_path in files:
        total_chunks += process_file(
            source_path=source_path,
            raw_root=raw_root,
            chunk_raw_root=chunk_raw_root,
            chunk_txt_root=chunk_txt_root,
            max_lines=args.max_lines,
            overlap=args.overlap,
        )

    print(f"[DONE] Files: {len(files)}")
    print(f"[DONE] Chunks: {total_chunks}")
    print(f"[DONE] Raw chunk folder: {chunk_raw_root}")
    print(f"[DONE] Metadata chunk folder: {chunk_txt_root}")


if __name__ == "__main__":
    main()