#!/usr/bin/env python3
"""
base.py

Extract about 10% of the most important text from a TXT file using embeddings.

Install:
  pip install sentence-transformers numpy

Use:
  python base.py --input "file.txt"
  python base.py --input "file.txt" --out "summary.txt"
  python base.py --input "file.txt" --ratio 0.1

Default model:
  sentence-transformers/all-MiniLM-L6-v2
"""

import argparse
import re
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def split_sentences(text: str) -> list[str]:
    text = re.sub(r"\s+", " ", text).strip()

    if not text:
        return []

    parts = re.split(r"(?<=[.!?。！？])\s+", text)

    if len(parts) <= 3:
        size = 600
        parts = [text[i:i + size] for i in range(0, len(text), size)]

    return [p.strip() for p in parts if len(p.strip()) > 20]


def cosine_similarity_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a_norm = a / np.clip(np.linalg.norm(a, axis=1, keepdims=True), 1e-9, None)
    b_norm = b / np.clip(np.linalg.norm(b, axis=1, keepdims=True), 1e-9, None)
    return a_norm @ b_norm.T


def extract_important_text(
    text: str,
    ratio: float = 0.1,
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
) -> str:
    sentences = split_sentences(text)

    if not sentences:
        return ""

    if len(sentences) == 1:
        return sentences[0]

    model = SentenceTransformer(model_name)

    sent_emb = model.encode(sentences, convert_to_numpy=True, normalize_embeddings=True)
    doc_emb = sent_emb.mean(axis=0, keepdims=True)

    centrality = cosine_similarity_matrix(sent_emb, doc_emb).reshape(-1)

    selected = []
    selected_set = set()

    target_chars = max(1, int(len(text) * ratio))
    current_chars = 0

    ranked = list(np.argsort(-centrality))

    for idx in ranked:
        if current_chars >= target_chars:
            break

        if selected:
            cand = sent_emb[idx:idx + 1]
            chosen = sent_emb[selected]
            max_sim = float(cosine_similarity_matrix(cand, chosen).max())
            if max_sim > 0.88:
                continue

        selected.append(idx)
        selected_set.add(idx)
        current_chars += len(sentences[idx])

    for idx in ranked:
        if current_chars >= target_chars:
            break
        if idx not in selected_set:
            selected.append(idx)
            selected_set.add(idx)
            current_chars += len(sentences[idx])

    selected = sorted(selected)

    return "\n".join(sentences[i] for i in selected)


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract 10% most important text from TXT using embeddings.")
    parser.add_argument("--input", required=True, help="Input txt file")
    parser.add_argument("--out", default=None, help="Output summary txt")
    parser.add_argument("--ratio", type=float, default=0.1, help="Keep ratio, default 0.1 = 10%")
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2", help="Embedding model")
    args = parser.parse_args()

    input_path = Path(args.input)

    if not input_path.exists():
        raise SystemExit(f"[ERROR] Input not found: {input_path}")

    text = read_text(input_path)

    summary = extract_important_text(
        text=text,
        ratio=args.ratio,
        model_name=args.model,
    )

    out_path = Path(args.out) if args.out else input_path.with_name(input_path.stem + "_summary10.txt")

    header = f"""# 10% IMPORTANT TEXT SUMMARY

Source: `{input_path.resolve()}`
Ratio: `{args.ratio}`
Method: `embedding centrality extractive summary`

---

"""

    out_path.write_text(header + summary.strip() + "\n", encoding="utf-8")

    print(f"[DONE] Summary saved to: {out_path}")


if __name__ == "__main__":
    main()
