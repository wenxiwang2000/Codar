#!/usr/bin/env python3
"""
chunks2contents.py

Embedding-based chunk summarizer.

No llama. No GGUF.

Reads chunk .txt files, keeps raw/chunk paths, uses base.py embedding logic
to extract about 10% most important text from each chunk, then writes summary.txt.

Use:
  python chunks2contents.py --input memory/chunk2contents/input_chunks --out memory/chunk2contents/summary/summary.txt --ratio 0.1
"""

import argparse
import re
from collections import defaultdict
from pathlib import Path

from base import extract_important_text


def file_uri(path: Path) -> str:
    try:
        return path.resolve().as_uri()
    except Exception:
        return str(path)


def path_to_uri(path_text: str) -> str:
    path_text = path_text.strip()
    if path_text.startswith("file:///"):
        return path_text
    try:
        return Path(path_text).resolve().as_uri()
    except Exception:
        return path_text


def extract_raw_path(chunk_text: str) -> str | None:
    patterns = [
        r"Source path:\s*`([^`]+)`",
        r"Source path:\s*(.+)",
        r"RAW LINK:\s*(.+)",
    ]

    for pattern in patterns:
        m = re.search(pattern, chunk_text)
        if m:
            value = m.group(1).strip()
            if value:
                return value
    return None


def extract_raw_chunk_path(chunk_text: str) -> str | None:
    patterns = [
        r"Raw chunk file:\s*(file:///\S+)",
        r"Raw chunk file:\s*`([^`]+)`",
        r"Raw chunk file:\s*(.+)",
    ]

    for pattern in patterns:
        m = re.search(pattern, chunk_text)
        if m:
            value = m.group(1).strip()
            if value:
                return value
    return None


def group_key(chunk_file: Path) -> str:
    stem = chunk_file.stem
    stem = re.sub(r"__chunk_\d+$", "", stem)
    stem = re.sub(r"_part\d+$", "", stem)
    return str(chunk_file.parent / stem)


def list_chunk_txt_files(input_root: Path, filter_text: str | None) -> list[Path]:
    files = []

    for p in input_root.rglob("*.txt"):
        if filter_text and filter_text.lower() not in str(p).lower():
            continue
        if "__chunk_" in p.name.lower() or "input_chunks" in [part.lower() for part in p.parts]:
            files.append(p)

    return sorted(files)


def remove_metadata_header(chunk_text: str) -> str:
    """
    Keep content after --- if metadata header exists.
    This avoids summarizing only file paths.
    """
    if "\n---\n" in chunk_text:
        return chunk_text.split("\n---\n", 1)[1].strip()
    return chunk_text.strip()


def summarize_files(
    files: list[Path],
    ratio: float,
    model_name: str,
) -> list[str]:
    groups = defaultdict(list)

    for f in files:
        groups[group_key(f)].append(f)

    lines = []
    lines.append("# EMBEDDING SUMMARY")
    lines.append("")
    lines.append(f"Method: `embedding centrality extractive summary`")
    lines.append(f"Ratio: `{ratio}`")
    lines.append(f"Chunk files: `{len(files)}`")
    lines.append("")

    for group in sorted(groups.keys()):
        chunk_files = sorted(groups[group])
        title = Path(group).name

        first_text = chunk_files[0].read_text(encoding="utf-8", errors="ignore")
        raw_path = extract_raw_path(first_text)

        lines.append(f"## {title}")

        if raw_path:
            lines.append(f"RAW FILE: {path_to_uri(raw_path)}")

        lines.append("")

        for chunk_file in chunk_files:
            chunk_text = chunk_file.read_text(encoding="utf-8", errors="ignore")
            raw_path_each = extract_raw_path(chunk_text) or raw_path
            raw_chunk_path = extract_raw_chunk_path(chunk_text)

            content_only = remove_metadata_header(chunk_text)
            summary = extract_important_text(
                text=content_only,
                ratio=ratio,
                model_name=model_name,
            )

            lines.append(f"- CHUNK TXT: {file_uri(chunk_file)}")

            if raw_chunk_path:
                lines.append(f"  RAW CHUNK: {path_to_uri(raw_chunk_path)}")

            if raw_path_each:
                lines.append(f"  RAW FILE: {path_to_uri(raw_path_each)}")

            lines.append("  SUMMARY:")
            lines.append("")
            lines.append(summary.strip() if summary.strip() else "[empty]")
            lines.append("")

    return lines


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize chunks using embedding extraction, no llama.")
    parser.add_argument("--input", default="memory/chunk2contents/input_chunks")
    parser.add_argument("--out", default="memory/chunk2contents/summary/summary.txt")
    parser.add_argument("--ratio", type=float, default=0.1)
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
    parser.add_argument("--filter", default=None)
    args = parser.parse_args()

    input_root = Path(args.input)
    out_path = Path(args.out)

    if not input_root.exists():
        raise SystemExit(f"[ERROR] input folder not found: {input_root}")

    files = list_chunk_txt_files(input_root, args.filter)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    if not files:
        out_path.write_text("# EMBEDDING SUMMARY\n\nNo chunk txt files found.\n", encoding="utf-8")
        print(f"[INFO] No chunk txt files found. Empty summary written to {out_path}")
        return

    print(f"[INFO] Found chunks: {len(files)}")
    print(f"[INFO] Using embedding model: {args.model}")

    lines = summarize_files(
        files=files,
        ratio=args.ratio,
        model_name=args.model,
    )

    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"[DONE] Wrote embedding summary to {out_path}")


if __name__ == "__main__":
    main()
