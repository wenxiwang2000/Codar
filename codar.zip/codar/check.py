#!/usr/bin/env python3
"""
check.py

Search your memory summaries by one sentence.

It compares your input sentence against all embedded chunk summaries and returns
the closest chunk.

Use:
  python check.py --query "how does the frame vocabulary app work?"
  python check.py --query "OCR PDF extraction" --top-k 5
  python check.py --memory memory --query "your question"

Needs files created by:
  python bigboss.py --folder "..." --chunk-size 500 --embed

Reads:
  memory/embeddings/embedding_entries.json
  memory/embeddings/embedding_vectors.json
"""

import argparse
import json
import re
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer


def load_json(path: Path) -> Any:
    if not path.exists():
        raise SystemExit(f"[ERROR] Missing file: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def normalize(v: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(v)
    if norm <= 1e-12:
        return v
    return v / norm


def embed_text(text: str, dim: int) -> np.ndarray:
    vectorizer = HashingVectorizer(
        n_features=dim,
        alternate_sign=False,
        norm="l2",
    )
    x = vectorizer.transform([text])
    return x.toarray()[0].astype(float)


def short_file_name_from_key(chunk_key: str) -> str:
    """
    Try to make a readable file/chunk title from file URI or path.
    """
    text = chunk_key.replace("file:///", "")
    text = text.replace("%20", " ")
    name = Path(text).name

    if not name:
        name = chunk_key

    name = re.sub(r"__chunk_\d+\.txt$", "", name)
    name = re.sub(r"\.txt$", "", name)

    return name


def search(
    query: str,
    entries: list[dict[str, str]],
    vectors: dict[str, list[float]],
    dim: int,
    top_k: int,
) -> list[dict[str, Any]]:
    q_vec = normalize(embed_text(query, dim))

    results = []

    for item in entries:
        key = item.get("chunk_key", "")
        summary = item.get("summary_text", "")

        if not key or key not in vectors:
            continue

        v = normalize(np.array(vectors[key], dtype=float))
        score = float(np.dot(q_vec, v))

        results.append(
            {
                "score": score,
                "file_title": short_file_name_from_key(key),
                "chunk_key": key,
                "summary": summary,
            }
        )

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_k]


def main() -> None:
    parser = argparse.ArgumentParser(description="Find closest memory chunk from one sentence.")
    parser.add_argument("--memory", default="memory", help="Root memory folder")
    parser.add_argument("--query", required=True, help="One sentence input query")
    parser.add_argument("--top-k", type=int, default=3, help="Number of best chunks to show")
    parser.add_argument("--dim", type=int, default=256, help="Embedding dimension, must match embedding.py")
    args = parser.parse_args()

    memory = Path(args.memory)
    embed_dir = memory / "embeddings"

    entries_path = embed_dir / "embedding_entries.json"
    vectors_path = embed_dir / "embedding_vectors.json"

    entries = load_json(entries_path)
    vectors = load_json(vectors_path)

    results = search(
        query=args.query,
        entries=entries,
        vectors=vectors,
        dim=args.dim,
        top_k=args.top_k,
    )

    if not results:
        print("[INFO] No matching entries found.")
        return

    print("\n# BEST MATCHES\n")

    for i, r in enumerate(results, start=1):
        print(f"## {i}. {r['file_title']}")
        print(f"Score: {r['score']:.4f}")
        print(f"Chunk: {r['chunk_key']}")
        print("")
        print(r["summary"])
        print("")


if __name__ == "__main__":
    main()
